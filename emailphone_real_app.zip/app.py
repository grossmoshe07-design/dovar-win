import sys
import os
from PySide6.QtCore import QUrl, Qt, QTimer
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication, QMainWindow, QSplashScreen
from PySide6.QtWebEngineWidgets import QWebEngineView
import requests

ONLINE_URL = "https://emailphone.free.nf"
OFFLINE_PATH = os.path.join(os.path.dirname(__file__), "local_site", "index.html")

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("EmailPhone App")
        self.setWindowIcon(QIcon("icon.ico"))
        self.resize(1100, 780)
        self.browser = QWebEngineView()
        self.setCentralWidget(self.browser)
        self.load_website()

    def load_website(self):
        try:
            r = requests.get(ONLINE_URL, timeout=4)
            if r.status_code == 200:
                self.browser.load(QUrl(ONLINE_URL))
                return
        except:
            pass
        self.browser.load(QUrl.fromLocalFile(OFFLINE_PATH))

def show_splash(app):
    pixmap = QIcon("splash.png").pixmap(420,420)
    splash = QSplashScreen(pixmap)
    splash.setWindowFlag(Qt.FramelessWindowHint)
    splash.show()
    app.processEvents()
    return splash

def main():
    app = QApplication(sys.argv)
    splash = show_splash(app)
    window = MainWindow()
    QTimer.singleShot(1500, lambda: (splash.close(), window.show()))
    sys.exit(app.exec())

if __name__=="__main__":
    main()
